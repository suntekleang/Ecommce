import { DeleteComponent } from './../components/delete/delete.component';
import { AddCategoryComponent } from './add-category/add-category.component';
import { AddProductComponent } from './add-product/add-product.component';
import { UploadCoverComponent } from './upload-cover/upload-cover.component';
export const APP_DIALOG=[
  AddCategoryComponent,
  DeleteComponent,
  AddProductComponent,
  UploadCoverComponent
]