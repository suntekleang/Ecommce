export interface ICategory {
  name:string;
  createBy:any;
  createDate:Date;
  key:string;
}
