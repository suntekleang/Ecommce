import {MatInputModule,MatToolbarModule,MatFormFieldModule,MatIconModule,MatButtonModule, MatCheckboxModule,MatAutocompleteModule, MatDialogModule, MatProgressSpinnerModule, MatListModule, MatTableModule, MatMenuModule, MatSnackBarModule} from '@angular/material';
export const MATERIAL_MODULE=[
  MatButtonModule,
  MatCheckboxModule,
  MatAutocompleteModule,
  MatIconModule,
  MatFormFieldModule,
  MatInputModule,
  MatToolbarModule,
  MatDialogModule,
  MatProgressSpinnerModule,
  MatListModule,
  MatTableModule,
  MatMenuModule,
  MatSnackBarModule
]