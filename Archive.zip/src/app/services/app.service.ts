import { DataService } from './data.service';
export const APP_SERVICES=[
  DataService
]