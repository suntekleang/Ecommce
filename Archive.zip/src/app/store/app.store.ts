import { Category } from './category.store';
import { User } from './user.store';
import { Product } from './product.store';
export const APP_STORE=[
  Category,
  User,
  Product
]